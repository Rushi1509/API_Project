package InfraS.InfraS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Primary;

import kiran.extra.A;

@SpringBootApplication
@ComponentScan ("InfraS")
public class InfraSApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfraSApplication.class, args);
	}
	@Bean
	A createObject(){
		System.err.println("   createObject........");
		return new A();
	}
}
