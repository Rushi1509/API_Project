package InfraS.InfraS;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.stereotype.Component;

public class InfraStructureService {
	
	
	@Autowired
	InfraStructureService infrasturture;
	public ArrayList<Bridge> informationOfBridge(){
	ArrayList<Bridge>serv = new ArrayList<Bridge>();
		ArrayList<Bridge>  infra=infrasturture.informationOfBridge();
		return infra;
	}
	
}
