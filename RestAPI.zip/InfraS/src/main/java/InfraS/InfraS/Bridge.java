package InfraS.InfraS;

public class Bridge {
	private int bridgeNo;
	private String bridgeName;
	private String bridgeLength;
	private String bridgeBreadth;
	
	
	public Bridge() {
		super();
	}
	public Bridge(int bridgeNo, String bridgeName, String bridgeLength, String bridgeBreadth) {
		super();
		this.bridgeNo = bridgeNo;
		this.bridgeName = bridgeName;
		this.bridgeLength = bridgeLength;
		this.bridgeBreadth = bridgeBreadth;
	}
	public int getBridgeNo() {
		return bridgeNo;
	}
	public void setBridgeNo(int bridgeNo) {
		this.bridgeNo = bridgeNo;
	}
	public String getBridgeName() {
		return bridgeName;
	}
	public void setBridgeName(String bridgeName) {
		this.bridgeName = bridgeName;
	}
	public String getBridgeLength() {
		return bridgeLength;
	}
	public void setBridgeLength(String bridgeLength) {
		this.bridgeLength = bridgeLength;
	}
	public String getBridgeBreadth() {
		return bridgeBreadth;
	}
	public void setBridgeBreadth(String bridgeBreadth) {
		this.bridgeBreadth = bridgeBreadth;
	}
	@Override
	public String toString() {
		return "Bridge [bridgeNo=" + bridgeNo + ", bridgeName=" + bridgeName + ", bridgeLength=" + bridgeLength
				+ ", bridgeBreadth=" + bridgeBreadth + "]";
	}
	

}
