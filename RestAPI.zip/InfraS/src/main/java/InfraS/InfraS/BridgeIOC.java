package InfraS.InfraS;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;
@Repository
public class BridgeIOC {
	public ArrayList<Bridge> informatio(){
		ArrayList<Bridge> bride = new ArrayList<>();
		Bridge brd = new Bridge(101, "pune", "600", "500" );
		Bridge brd1 = new Bridge(102, "pune", "600", "500" );
		Bridge brd2 = new Bridge(103, "pune", "600", "500" );
		Bridge brd3= new Bridge(104, "pune", "600", "500" );
		bride.add(brd);
		bride.add(brd1);
		bride.add(brd2);
		bride.add(brd3);
		return bride;
	
	
	}
}
