package InfraS.InfraS;

import org.springframework.stereotype.Component;

@Component
public class X {
	X(){
		System.err.println("Hello..Hii... Welcome");
	}
	
	void m2(){
		System.err.println("THIS IS ANNOTATION");
	}
}
	
	
	