package InfraS.InfraS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class InfraStructureDao {
	
	ArrayList<Bridge>infromationOfBrige(){
		ArrayList<Bridge> bridge = new ArrayList<Bridge>();
		Bridge brd = new Bridge(101, "pune", "600", "453");
		Bridge brd1 = new Bridge(102, "mumbai", "345", "452");
		bridge.add(brd);
		bridge.add(brd1);
		return bridge;
		}
	}
