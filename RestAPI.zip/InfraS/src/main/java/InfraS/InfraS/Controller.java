package InfraS.InfraS;

import java.util.ArrayList;

import org.springframework.aop.IntroductionAdvisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import kiran.extra.A;
import net.bytebuddy.implementation.bytecode.collection.ArrayLength;

@RestController
public class Controller {
	
	@Autowired
	@Qualifier ("createObject")
	A aa = null;
	
	
	
	
	@Value("${brigecost12}")
	int bridgecost;
	
	@Autowired
	BridgeIOC ioc = null;
	
	@Autowired
	X xx = new X();
	@GetMapping ("InfraIOC")
	public void infrastructureIOC(){
			xx.m2();
	}
	
	@RequestMapping ("bridgecount")
	int bridge(){
		return 646;
	}
	@RequestMapping ("Infromation")
	Bridge info(){
		Bridge brd= new Bridge(100, "mumbai", "550", "340");
		return  brd;
	}
	
	@GetMapping("checkobjectcreation")
	public void leanIOC(){
		System.out.println("bridgecost>>>"+ bridgecost);
	}
	
	
	@GetMapping("Infra")
	ArrayList<Bridge>infromationOfBrige(){
		ArrayList<Bridge> brid =  new ArrayList<Bridge>();
		InfraStructureService infra = new InfraStructureService();
		return brid;
	}
	@GetMapping("NewInfor/{cityname}")
	ArrayList<Bridge> Bridge(@PathVariable String cityname ){
		System.out.println("It was a information >>" + cityname);
		ArrayList<Bridge> list1 = new ArrayList<Bridge>();
		Bridge brd = new Bridge(101, "pune", "600", "500" );
		Bridge brd1 = new Bridge(102, "pune", "600", "500" );
		Bridge brd2 = new Bridge(103, "pune", "600", "500" );
		Bridge brd3= new Bridge(104, "pune", "600", "500" );
		list1.add(brd);
		list1.add(brd1);
		list1.add(brd2);
		list1.add(brd3);
		return list1;
		
	}
	
	@PostMapping("Addnewinfo")
	public void addinformation (@RequestBody Bridge bridge){
		System.out.println("new information>>" +bridge);
	}
	@RequestMapping ("IOC")
	ArrayList<Bridge> informatio(){
		ArrayList<Bridge> brid = new ArrayList<>();
	
	ArrayList<Bridge> br = ioc.informatio();
	return br;
	}

}
