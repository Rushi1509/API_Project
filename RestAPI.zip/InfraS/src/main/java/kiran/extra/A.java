package kiran.extra;

import org.springframework.stereotype.Component;
@Component
public class A {
	
	 public A(){
		System.err.println("A IS CONTRUCTOR");
	}
	void mx(){
		System.err.println("i am extra...A...mx");
	}

}
