package kiran.extra;

import org.springframework.context.annotation.Bean;

public class B {
	
}